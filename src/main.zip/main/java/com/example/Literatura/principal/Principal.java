package com.example.Literatura.principal;
import com.example.Literatura.model.DatosLibros;
import com.example.Literatura.model.Idioma;
import com.example.Literatura.model.Wrapper;
import com.example.Literatura.service.ConsumoApi;
import com.example.Literatura.service.ConvierteDatos;

import com.example.Literatura.Repository.LibroRepository;
import com.example.Literatura.model.LibroEntity;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;
import java.util.stream.Collectors;

import java.util.Scanner;

public class Principal {
    private Scanner teclado = new Scanner(System.in);
    private ConsumoApi consumoApi = new ConsumoApi();
    private final String URL_BASE = "https://gutendex.com/books/";
    private ConvierteDatos conversor = new ConvierteDatos();
    private List<DatosLibros> datosLibros = new ArrayList<>();
    private LibroRepository repositorio;

    public Principal(LibroRepository repository) {
        this.repositorio = repository;
    }

    public void muestraElMenu(){
        var opcion = -1;
        while (opcion !=0){
            var menu="""
            1 - Buscar por título
            2 - Buscar libros registrados
            3 - Lista de autores registrados
            4 - Lista de autores vivos en determinado año
            5 - Lista de libros por idioma
            
            0 - Salir
            """;
            System.out.println(menu);
            opcion = teclado.nextInt();
            teclado.nextLine();
            switch (opcion){
                case 1:
                    buscarPorTitulo();
                    break;
                case 2:
                    buscarPorTitulo();
                    break;
                case 3:
                    buscarPorTitulo();
                    break;
                case 4:
                    buscarPorTitulo();
                    break;
                case 5:
                    buscarPorTitulo();
                    break;
                default:
                    System.out.println("Opción invalida");
            }
        }
    }

    private DatosLibros getDatosLibros() {
        System.out.println("Escribe el nombre de la serie que deseas buscar");
        var nombreSerie = teclado.nextLine();
        var json = consumoApi.obtenerDatos(URL_BASE + nombreSerie.replace(" ", "+"));
        System.out.println(json);
        DatosLibros datos = conversor.obtenerDatos(json, DatosLibros.class);
        return datos;
    }


    private void buscarPorTitulo() {
        DatosLibros datosLibros = getDatosLibros();
        List<DatosLibros> datosLibros1 = new ArrayList<>();


    }


}
