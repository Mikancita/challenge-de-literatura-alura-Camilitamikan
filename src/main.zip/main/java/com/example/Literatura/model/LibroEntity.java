package com.example.Literatura.model;


import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name="libros")
public class LibroEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(unique = true)
    private String titulo;
    private String autor;
    @Enumerated(EnumType.STRING)
    private String idioma;
    private Integer numerodescargas;
//    @Transient
//    private List<Autor>;
//
    public LibroEntity(){

    }
//    public LibroEntity(String titulo, String autor, String idioma, Integer numerodescargas) {
//        this.titulo = titulo;
//        this.autor = autor;
//        this.idioma = idioma;
//        this.numerodescargas = numerodescargas;
//    }
    public LibroEntity(DatosLibros datosLibros){
        this.titulo = datosLibros.titulo();
        this.autor = datosLibros.autores();
        this.numerodescargas = datosLibros.Numerodescargas();
        this.idioma = String.valueOf(Idioma.fromString(datosLibros.idioma().split(",")[0].trim()));

    }

    @Override
    public String toString() {
        return  ", titulo='" + titulo + '\'' +
                ", autor='" + autor + '\'' +
                ", idioma='" + idioma + '\'' +
                ", numerodescargas=" + numerodescargas + '\'';
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }

    public Integer getNumerodescargas() {
        return numerodescargas;
    }

    public void setNumerodescargas(Integer numerodescargas) {
        this.numerodescargas = numerodescargas;
    }
}
